import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from inference import translate


def evaluate_bleu(test_sentences, true_translations, encoder, decoder,
                  inp_tokenizer, targ_tokenizer, max_len_inp, max_len_targ):
    smoothie = SmoothingFunction().method4
    scores = []

    for i in range(len(test_sentences)):
        pred = translate(test_sentences[i], encoder, decoder,
                         inp_tokenizer, targ_tokenizer,
                         max_len_inp, max_len_targ)

        ref = true_translations[i].split()
        hyp = pred.split()

        bleu_score = sentence_bleu([ref], hyp, smoothing_function=smoothie)
        scores.append(bleu_score)

        print(f"\n🔹 Sentence {i+1}")
        print(f"Input:        {test_sentences[i]}")
        print(f"Reference:    {true_translations[i]}")
        print(f"Prediction:   {pred}")
        print(f"BLEU Score:   {bleu_score:.4f}")

    avg_score = sum(scores) / len(scores)
    print(f"Average BLEU Score over {len(test_sentences)} examples: {avg_score:.4f}")