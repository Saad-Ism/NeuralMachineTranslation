import unicodedata
import re
import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences


def unicode_to_ascii(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s)
                   if unicodedata.category(c) != 'Mn')


def preprocess_sentence(s):
    s = unicode_to_ascii(s.lower().strip())
    s = re.sub(r"([?.!,¿])", r" \1 ", s)
    s = re.sub(r'[" "]+', " ", s)
    s = re.sub(r"[^a-zA-Z?.!,¿]+", " ", s)
    s =s.strip()
    return s

def load_data(path, num_examples=None):
    lines = open(path, encoding='utf-8').read().strip().split('\n')

    eng_sentences, fra_sentences = [], []
    for line in lines[:num_examples]:
        parts = line.split('\t')
        if len(parts) < 2:
            continue
        eng, fra = parts[0], parts[1]
        eng_sentences.append(preprocess_sentence(eng))
        fra_sentences.append('<start> ' + preprocess_sentence(fra) + ' <end>')

    return eng_sentences, fra_sentences

def tokenize(sentences):
    tokenizer = Tokenizer(filters='')
    tokenizer.fit_on_texts(sentences)
    sequences = tokenizer.texts_to_sequences(sentences)
    padded = pad_sequences(sequences, padding='post')
    return padded, tokenizer


def load_tokenized_data(path, num_examples=None):
    eng, fra = load_data(path, num_examples=num_examples)
    eng_tensor, eng_tokenizer = tokenize(eng)
    fra_tensor, fra_tokenizer = tokenize(fra)
    return eng_tensor, fra_tensor, eng_tokenizer, fra_tokenizer
