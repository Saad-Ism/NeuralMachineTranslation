import tensorflow as tf

def preprocess_sentence(sentence, tokenizer, max_length):
    sequence = tokenizer.texts_to_sequences([sentence])
    padded = tf.keras.preprocessing.sequence.pad_sequences(
        sequence,
        maxlen=max_length,
        padding="post"
    )
    return tf.convert_to_tensor(padded)

def translate(sentence, encoder, decoder, eng_tokenizer, fra_tokenizer, max_length_inp, max_length_tar):
    inputs = preprocess_sentence(sentence, eng_tokenizer, max_length_inp)
    hidden = encoder.initialize_hidden_state()

    enc_out, enc_hidden_h, enc_hidden_c = encoder(inputs, hidden)

    start_index = fra_tokenizer.word_index["<start>"]
    dec_input = tf.expand_dims([start_index], 1)
    dec_hidden = [enc_hidden_h, enc_hidden_c]

    result = []
    predicted_ids = []

    for t in range(max_length_tar):
        predictions, dec_hidden_h, dec_hidden_c = decoder(dec_input, dec_hidden)
        predictions = tf.squeeze(predictions, axis=1)
        predicted_id = tf.argmax(predictions[0]).numpy()
        predicted_ids.append(predicted_id)

        predicted_word = fra_tokenizer.index_word.get(predicted_id, '')
        print(f"[Step {t}] ID: {predicted_id}, Word: {predicted_word}")

        if predicted_word == '<end>':
            break

        result.append(predicted_word)

        dec_input = tf.expand_dims([predicted_id], 1)
        dec_hidden = (dec_hidden_h, dec_hidden_c)

    print("Final result:", result)
    print("Predicted token IDs:", predicted_ids)

    return ' '.join(result)