import tensorflow as tf
import os


#1. Loss Function
loss_object = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True, reduction='none')

def loss_function(real, pred):
    mask = tf.math.logical_not(tf.math.equal(real, 0))
    loss_ = loss_object(real, pred)

    mask = tf.cast(mask, dtype=loss_.dtype)
    loss_ *= mask
    return tf.reduce_mean(loss_)

#2. Optimizer
optimizer = tf.keras.optimizers.Adam()

#3. Training step (wrapped with @tf.function for performance)
@tf.function
def train_step(inp, targ, enc_hidden, encoder, decoder, tokenizer):
    loss = 0

    with tf.GradientTape() as tape:
        enc_output, enc_hidden_h, enc_hidden_c = encoder(inp, enc_hidden)

        dec_input = tf.expand_dims(targ[:, 0], 1)
        dec_hidden = (enc_hidden_h, enc_hidden_c)

        for t in range(1, targ.shape[1]):
            predictions, dec_hidden_h, dec_hidden_c = decoder(dec_input, dec_hidden)
            predictions = tf.squeeze(predictions, axis=1)
            loss += loss_function(targ[:, t], predictions)
            dec_input = tf.expand_dims(targ[:, t], 1)
            dec_hidden = (dec_hidden_h, dec_hidden_c)

    batch_loss = loss / int(targ.shape[1])
    variables = encoder.trainable_variables + decoder.trainable_variables
    gradients = tape.gradient(loss, variables)
    optimizer.apply_gradients(zip(gradients, variables))

    return batch_loss

def train(encoder, decoder, dataset, tokenizer, epochs, steps_per_epoch, checkpoint, checkpoint_prefix):
    for epoch in range(epochs):
        total_loss = 0
        enc_hidden = encoder.initialize_hidden_state()

        for (batch, (inp, targ)) in enumerate(dataset.take(steps_per_epoch)):
            batch_loss = train_step(inp, targ, enc_hidden, encoder, decoder, tokenizer)
            total_loss += batch_loss

            if batch % 100 == 0:
                print(f"Epoch {epoch + 1} Batch {batch} Loss {batch_loss.numpy():.4f}")

        checkpoint.save(file_prefix=checkpoint_prefix)
        print(f"Epoch {epoch + 1} Loss {total_loss / steps_per_epoch:.4f}")