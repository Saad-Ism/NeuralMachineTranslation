import tensorflow as tf
from model_no_attention import Encoder, Decoder
from preprocessing import load_tokenized_data
from train import train
from inference import translate
import os
from evaluate import evaluate_bleu

# Load data
eng_tensor, fra_tensor, eng_tokenizer, fra_tokenizer = load_tokenized_data('eng-fra.txt', num_examples=10000)

BUFFER_SIZE = len(eng_tensor)
BATCH_SIZE = 64
embedding_dim = 256
units = 512

vocab_inp_size = len(eng_tokenizer.word_index) + 1
vocab_tar_size = len(fra_tokenizer.word_index) + 1

steps_per_epoch = BUFFER_SIZE // BATCH_SIZE

optimizer = tf.keras.optimizers.Adam()

dataset = tf.data.Dataset.from_tensor_slices((eng_tensor, fra_tensor))
dataset = dataset.shuffle(BUFFER_SIZE).batch(BATCH_SIZE, drop_remainder=True)

# Create Models
encoder = Encoder(vocab_inp_size, embedding_dim, units, BATCH_SIZE)
decoder = Decoder(vocab_tar_size, embedding_dim, units, BATCH_SIZE)

# -----------------------
# Force build encoder/decoder with dummy inputs
# -----------------------
max_length_inp = eng_tensor.shape[1]
max_length_tar = fra_tensor.shape[1]

sample_input = tf.random.uniform((1, max_length_inp))
sample_hidden = encoder.initialize_hidden_state()
sample_output, sample_state_h, sample_state_c = encoder(sample_input, sample_hidden)

sample_decoder_input = tf.expand_dims([fra_tokenizer.word_index['<start>']], 0)
_ = decoder(sample_decoder_input, (sample_state_h, sample_state_c))

checkpoint_dir = './checkpoints'
checkpoint_prefix = os.path.join(checkpoint_dir, "ckpt")

EPOCHS = 1

checkpoint = tf.train.Checkpoint(optimizer=optimizer,
                                 encoder=encoder,
                                 decoder=decoder)

latest = tf.train.latest_checkpoint(checkpoint_dir)
if latest:
    print("🔁 Restoring from checkpoint:", latest)
    checkpoint.restore(latest)

#train(encoder, decoder, dataset, fra_tokenizer, EPOCHS, steps_per_epoch, checkpoint, checkpoint_prefix)

# Inference

test_sentence = "go ."
translation =  translate(test_sentence, encoder, decoder,
                         eng_tokenizer, fra_tokenizer,
                         max_length_inp, max_length_tar)

print(f"Input: {test_sentence}")
print(f"Predicted French: {translation}")

test_eng = ["go .", "i am cold .", "she is here ."]
test_fra = ["va !", "j'ai froid .", "elle est ici ."]

evaluate_bleu(test_eng, test_fra, encoder, decoder,
              eng_tokenizer, fra_tokenizer,
              max_length_inp, max_length_tar)
